import io.cucumber.junit.CucumberSerenityRunner;
import net.serenitybdd.annotations.Managed;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

@RunWith(CucumberSerenityRunner.class)
public class RegisterUser {
    @Managed
    WebDriver driver;
    @Test
    public void myGoogleSearch() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("https://automationexercise.com/");
        driver.findElement(By.xpath("/html/body")).isDisplayed();
        driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a/text()")).click();
        driver.findElement(By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/h2")).isDisplayed();
        driver.findElement(By.name("name")).sendKeys("Sakshi");
        driver.findElement(By.name("email")).sendKeys("sia123@gmail.com");
        driver.findElement(By.linkText("Signup")).click();
        
    }
}

