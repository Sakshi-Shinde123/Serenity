import io.cucumber.junit.CucumberSerenityRunner;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.core.pages.PageObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

@RunWith(CucumberSerenityRunner.class)
public class Demo {
    @Managed
    WebDriver driver;
    @Test
    public void myGoogleSearch() throws InterruptedException {
        driver.get("https://www.google.com/");
        driver.findElement(By.name("q")).sendKeys("Selenium with Serenity");
    }
}
